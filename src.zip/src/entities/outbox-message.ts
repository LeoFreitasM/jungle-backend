export interface IntegrationEventLike {
  eventId: string;
  eventType: string;
  aggregateId: string;
  occurredAt: Date;
  toJSON(): Record<string, unknown>;
}

export interface OutboxMessageState {
  id: string;
  aggregateId: string;
  eventType: string;
  payload: Record<string, unknown>;
  occurredAt: Date;
  attempts: number;
  nextAttemptAt?: Date;
  publishedAt?: Date;
}

export class OutboxMessage {
  private constructor(
    public readonly id: string,
    public readonly aggregateId: string,
    public readonly eventType: string,
    public readonly payload: Readonly<Record<string, unknown>>,
    public readonly occurredAt: Date,
    private _attempts: number,
    private _nextAttemptAt?: Date,
    private _publishedAt?: Date,
  ) {}

  static enqueue(event: IntegrationEventLike): OutboxMessage {
    return new OutboxMessage(
      event.eventId,
      event.aggregateId,
      event.eventType,
      OutboxMessage.deepFreeze(event.toJSON()),
      new Date(event.occurredAt),
      0,
    );
  }

  static rehydrate(state: OutboxMessageState): OutboxMessage {
    return new OutboxMessage(
      state.id,
      state.aggregateId,
      state.eventType,
      OutboxMessage.deepFreeze(state.payload),
      new Date(state.occurredAt),
      state.attempts,
      state.nextAttemptAt
        ? new Date(state.nextAttemptAt)
        : undefined,
      state.publishedAt
        ? new Date(state.publishedAt)
        : undefined,
    );
  }

  get attempts(): number {
    return this._attempts;
  }

  get nextAttemptAt(): Date | undefined {
    return this._nextAttemptAt
      ? new Date(this._nextAttemptAt)
      : undefined;
  }

  get publishedAt(): Date | undefined {
    return this._publishedAt
      ? new Date(this._publishedAt)
      : undefined;
  }

  isPending(): boolean {
    return this._publishedAt === undefined;
  }

  isDue(now: Date = new Date()): boolean {
    if (!this.isPending()) {
      return false;
    }

    return (
      this._nextAttemptAt === undefined ||
      this._nextAttemptAt.getTime() <= now.getTime()
    );
  }

  markPublished(at: Date = new Date()): void {
    if (!this.isPending()) {
      throw new Error('Outbox message was already published');
    }

    this._publishedAt = new Date(at);
  }

  scheduleRetry(now: Date = new Date()): void {
    if (!this.isPending()) {
      throw new Error('Cannot retry a published outbox message');
    }

    this._attempts += 1;

    const baseDelayMs = 1_000;
    const maxDelayMs = 15 * 60 * 1_000;

    const delayMs = Math.min(
      baseDelayMs * 2 ** (this._attempts - 1),
      maxDelayMs,
    );

    this._nextAttemptAt = new Date(
      now.getTime() + delayMs,
    );
  }

  private static deepFreeze<T extends Record<string, unknown>>(
    value: T,
  ): Readonly<T> {
    const copy = JSON.parse(JSON.stringify(value)) as T;

    const freeze = (item: unknown): void => {
      if (
        item === null ||
        typeof item !== 'object' ||
        Object.isFrozen(item)
      ) {
        return;
      }

      Object.freeze(item);

      for (const child of Object.values(item)) {
        freeze(child);
      }
    };

    freeze(copy);

    return copy;
  }
}