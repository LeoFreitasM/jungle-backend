
import {
  Body,
  Controller,
  Headers,
  Post,
  BadRequestException,
} from '@nestjs/common';
import { randomUUID, createHash } from 'node:crypto';

import { CreateWagerDto } from '../dtos/create-wager.dto.js';
import { WagerTransaction } from '../entities/wager-transaction.js';
import { Money } from '../value-objects/money.js';
import { WagerPersistenceService } from '../services/wager-persistence.service.js';

@Controller('wagers')
export class WagerController {
  constructor(
    private readonly wagerPersistenceService: WagerPersistenceService,
  ) {}

  @Post()
  async create(
    @Body() dto: CreateWagerDto,
    @Headers('idempotency-key') idempotencyKey: string,
  ) {
    if (!idempotencyKey?.trim()) {
      throw new BadRequestException(
        'Idempotency-Key header is required',
      );
    }

    const payload = {
      playerId: dto.playerId,
      walletId: dto.walletId,
      amount: dto.amount,
      currency: dto.currency.toUpperCase(),
      kind: dto.kind,
      referenceTransactionId: dto.referenceTransactionId ?? null,
    };

    const payloadHash = createHash('sha256')
      .update(JSON.stringify(payload))
      .digest('hex');

    const transaction = WagerTransaction.create({
      id: randomUUID(),
      playerId: dto.playerId,
      walletId: dto.walletId,
      amount: Money.from({
        amount: dto.amount,
        currency: dto.currency,
      }),
      kind: dto.kind,
      referenceTransactionId: dto.referenceTransactionId,
    });

    const result = await this.wagerPersistenceService.process(
      transaction,
      idempotencyKey,
      payloadHash,
    );

    return {
      transactionId: result.transaction.id,
      status: result.transaction.status,
      ledgerEntry: result.ledgerEntry,
    };
  }
}
