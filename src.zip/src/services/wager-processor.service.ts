
import { Injectable } from '@nestjs/common';

import { Wallet } from '../entities/wallet.js';
import {
  WagerTransaction,
  WagerTransactionKind,
  WagerFailureCode,
} from '../entities/wager-transaction.js';
import { WalletLedgerEntry } from '../entities/wallet-ledger-entry.js';

@Injectable()
export class WagerProcessorService {
  process(
    transaction: WagerTransaction,
    wallet: Wallet,
  ): WalletLedgerEntry | null {
    if (transaction.walletId !== wallet.id) {
      transaction.reject(WagerFailureCode.INVALID_WALLET);
      throw new Error('Transaction does not belong to this wallet');
    }

    if (transaction.playerId !== wallet.playerId) {
      transaction.reject(WagerFailureCode.INVALID_WALLET);
      throw new Error('Transaction does not belong to this player');
    }

    if (transaction.amount.currency !== wallet.currency) {
      transaction.reject(WagerFailureCode.INVALID_CURRENCY);
      throw new Error('Transaction currency does not match wallet currency');
    }

    try {
      let ledgerEntry: WalletLedgerEntry | null = null;

      switch (transaction.kind) {
        case WagerTransactionKind.BET:
          ledgerEntry = wallet.debit(
            transaction.amount,
            transaction.id,
          );
          break;

        case WagerTransactionKind.WIN:
          ledgerEntry = wallet.credit(
            transaction.amount,
            transaction.id,
          );
          break;

        case WagerTransactionKind.LOSS:
          // LOSS registra o resultado, mas não movimenta o saldo.
          if (!transaction.amount.isZero()) {
            throw new Error('LOSS transaction amount must be zero');
          }
          break;

        default:
          throw new Error(
            `Transaction kind not supported yet: ${transaction.kind}`,
          );
      }

      transaction.markProcessed();

      return ledgerEntry;
    } catch (error) {
      if (error instanceof Error && error.message === 'Insufficient balance') {
        transaction.reject(WagerFailureCode.INSUFFICIENT_FUNDS);
      } else if (!transaction.isTerminal()) {
        transaction.reject(
          WagerFailureCode.BUSINESS_RULE_VIOLATION,
        );
      }

      throw error;
    }
  }
}
