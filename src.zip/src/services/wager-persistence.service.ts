
import {
  Injectable,
  ConflictException,
} from '@nestjs/common';
import { EntityManager } from '@mikro-orm/postgresql';

import {
  WagerTransaction,
  WagerTransactionStatus,
} from '../entities/wager-transaction.js';
import { WalletLedgerEntry } from '../entities/wallet-ledger-entry.js';

import { WalletRepository } from '../infrastructure/database/repositories/wallet.repository.js';
import { WagerTransactionRepository } from '../infrastructure/database/repositories/wager-transaction.repository.js';
import { WalletLedgerEntryRepository } from '../infrastructure/database/repositories/wallet-ledger-entry.repository.js';

import { WagerProcessorService } from './wager-processor.service.js';

@Injectable()
export class WagerPersistenceService {
  constructor(
    private readonly entityManager: EntityManager,
    private readonly walletRepository: WalletRepository,
    private readonly transactionRepository: WagerTransactionRepository,
    private readonly ledgerRepository: WalletLedgerEntryRepository,
    private readonly processor: WagerProcessorService,
  ) {}

  async process(
    transaction: WagerTransaction,
    idempotencyKey: string,
    payloadHash: string,
  ): Promise<{
    transaction: WagerTransaction;
    ledgerEntry: WalletLedgerEntry | null;
  }> {
    try {
      return await this.entityManager.transactional(async (tx) => {
        // Primeira verificação: evita processar uma repetição já concluída.
        const existingBeforeLock =
          await this.transactionRepository.findByIdempotencyKey(
            idempotencyKey,
            tx,
          );

        if (existingBeforeLock) {
          return this.resolveExisting(
            existingBeforeLock,
            payloadHash,
            tx,
          );
        }

        // O lock impede duas operações simultâneas de alterarem
        // o saldo da mesma carteira ao mesmo tempo.
        const wallet =
          await this.walletRepository.findByPlayerIdAndCurrency(
            transaction.playerId,
            transaction.amount.currency,
            tx,
            true,
          );

        if (!wallet) {
          throw new Error('Wallet not found');
        }

        // Segunda verificação: outra requisição pode ter concluído
        // a mesma chave enquanto esta aguardava o lock.
        const existingAfterLock =
          await this.transactionRepository.findByIdempotencyKey(
            idempotencyKey,
            tx,
          );

        if (existingAfterLock) {
          return this.resolveExisting(
            existingAfterLock,
            payloadHash,
            tx,
          );
        }

        let ledgerEntry: WalletLedgerEntry | null = null;

        try {
          ledgerEntry = this.processor.process(
            transaction,
            wallet,
          );
        } catch (error) {
          // Rejeições de negócio são persistidas para que a mesma
          // chave não possa tentar executar novamente a operação.
          if (
            transaction.status !== WagerTransactionStatus.REJECTED
          ) {
            throw error;
          }
        }

        // Só persiste a carteira quando houve movimentação.
        if (ledgerEntry) {
          await this.walletRepository.save(wallet, tx);
          await this.ledgerRepository.save(ledgerEntry, tx);
        }

        await this.transactionRepository.save(
          transaction,
          idempotencyKey,
          payloadHash,
          tx,
        );

        await tx.flush();

        return {
          transaction,
          ledgerEntry,
        };
      });
    } catch (error) {
      // Duas requisições com a mesma chave podem disputar a
      // constraint UNIQUE. Se outra já venceu, devolvemos o resultado.
      const existing =
        await this.transactionRepository.findByIdempotencyKey(
          idempotencyKey,
        );

      if (existing) {
        return this.resolveExisting(
          existing,
          payloadHash,
        );
      }

      throw error;
    }
  }

  private async resolveExisting(
    existing: {
      transaction: WagerTransaction;
      payloadHash: string;
    },
    payloadHash: string,
    em?: EntityManager,
  ): Promise<{
    transaction: WagerTransaction;
    ledgerEntry: WalletLedgerEntry | null;
  }> {
    if (existing.payloadHash !== payloadHash) {
      throw new ConflictException(
        'Idempotency key already used with a different payload',
      );
    }

    const previousLedger =
      await this.ledgerRepository.findByTransactionId(
        existing.transaction.id,
        em,
      );

    return {
      transaction: existing.transaction,
      ledgerEntry: previousLedger,
    };
  }
}
