
import {
  Entity,
  PrimaryKey,
  Property,
  Index,
} from '@mikro-orm/decorators/legacy';

import {
  WagerTransactionKind,
  WagerTransactionStatus,
  WagerFailureCode,
} from '../../../entities/wager-transaction.js';

@Entity({ tableName: 'wager_transactions' })
@Index({
  name: 'idx_wager_provider_external',
  properties: ['providerId', 'externalTransactionId'],
})
export class WagerTransactionEntity {
  @PrimaryKey({ type: 'uuid' })
  id!: string;

  @Property({ type: 'string', unique: true, nullable: true })
  idempotencyKey?: string;

  @Property({ type: 'string', length: 64, nullable: true })
  payloadHash?: string;

  @Property({ type: 'string', nullable: true })
  providerId?: string;

  @Property({ type: 'string', nullable: true })
  externalTransactionId?: string;

  @Property({ type: 'string', nullable: true })
  roundId?: string;

  @Property({ type: 'string', nullable: true })
  gameId?: string;

  @Property({ type: 'string', nullable: true })
  referenceExternalTransactionId?: string;

  @Property({ type: 'string' })
  playerId!: string;

  @Property({ type: 'uuid' })
  walletId!: string;

  @Property({ type: 'decimal', precision: 19, scale: 2 })
  amount!: string;

  @Property({ type: 'string', length: 3 })
  currency!: string;

  @Property({ type: 'string' })
  kind!: WagerTransactionKind;

  @Property({ type: 'string' })
  status!: WagerTransactionStatus;

  @Property({ type: 'string', nullable: true })
  referenceTransactionId?: string;

  @Property({ type: 'string', nullable: true })
  failureCode?: WagerFailureCode;

  @Property({ type: 'timestamptz', nullable: true })
  processedAt?: Date;

  @Property({ type: 'timestamptz' })
  createdAt = new Date();

  @Property({ type: 'timestamptz', onUpdate: () => new Date() })
  updatedAt = new Date();
}
