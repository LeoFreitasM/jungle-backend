import {
  IsString,
  IsUUID,
  Matches,
} from 'class-validator';

export class CreateWalletDto {
  @IsUUID()
  playerId: string;

  @IsString()
  @Matches(/^[A-Za-z]{3}$/)
  currency: string;

  @IsString()
  @Matches(/^\d+(\.\d{1,2})?$/)
  initialBalance: string;
}