import {
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  IsUUID,
  Matches,
} from 'class-validator';

import { WagerTransactionKind } from '../entities/wager-transaction.js';

export class CreateWagerDto {
  @IsUUID()
  playerId: string;

  @IsUUID()
  walletId: string;

  @IsString()
  @IsNotEmpty()
  @Matches(/^\d+(\.\d{1,2})?$/)
  amount: string;

  @IsString()
  @Matches(/^[A-Za-z]{3}$/)
  currency: string;

  @IsEnum(WagerTransactionKind)
  kind: WagerTransactionKind;

  @IsOptional()
  @IsUUID()
  referenceTransactionId?: string;
}